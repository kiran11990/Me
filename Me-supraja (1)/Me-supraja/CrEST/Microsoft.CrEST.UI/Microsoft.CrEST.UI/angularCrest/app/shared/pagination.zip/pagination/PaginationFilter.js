var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Input, Output, EventEmitter } from "@angular/core";
import { PaginationComponent } from "./pagination.component";
var PaginationFilter = (function () {
    function PaginationFilter() {
        this.notifyFilter = new EventEmitter();
        this.filterStr = "";
        this.title = "";
    }
    PaginationFilter.prototype.filter = function () {
        this.pagination.filter_By(this.filterBy, this.filterStr);
        this.notifyFilter.emit(this.pagination.paginationData);
    };
    return PaginationFilter;
}());
__decorate([
    Input("by"),
    __metadata("design:type", String)
], PaginationFilter.prototype, "filterBy", void 0);
__decorate([
    Input('pagination'),
    __metadata("design:type", PaginationComponent)
], PaginationFilter.prototype, "pagination", void 0);
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], PaginationFilter.prototype, "notifyFilter", void 0);
__decorate([
    Input("title"),
    __metadata("design:type", String)
], PaginationFilter.prototype, "title", void 0);
PaginationFilter = __decorate([
    Component({
        selector: "PaginationFilter",
        template: "\n        <input type=\"text\"  [attr.aria-label]=\"title\" [(ngModel)]=\"filterStr\" class=\"paginationFilter\" style=\"color:black;font-weight:normal;width:80%;height:20px;\" class=\"text-nowrap\" id=\"filterCol{{filterBy}}\"/>\n        <button (click)=\"filter()\" [attr.aria-label]=\"title\" title=\"Filter by {{title}}\" style=\"border:none;background:transparent;padding:2px;\" ><span style=\"cursor: pointer;font-family:'Segoe UI Symbol';\" id=\"filterIcon{{filterBy}}\">&#xE16E;</span></button>"
    }),
    __metadata("design:paramtypes", [])
], PaginationFilter);
export { PaginationFilter };
//# sourceMappingURL=PaginationFilter.js.map