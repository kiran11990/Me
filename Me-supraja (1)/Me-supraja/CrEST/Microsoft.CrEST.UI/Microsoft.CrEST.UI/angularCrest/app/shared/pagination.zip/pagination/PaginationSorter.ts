﻿import { Component, Input, Output, EventEmitter, OnInit } from "@angular/core";
import { PaginationComponent, SortEvent } from "./pagination.component";

@Component({
    selector: "PaginationSorter",
    template: `
<style>
.viewsheader:hover{
text-decoration:underline;
}
</style>
        <button [attr.aria-sort]="gridSortOrderby"  role="columnheader" aria-live="polite"  style="cursor: pointer;background:none;border:0px;margin-left:-7px" (click)="sort($event)" class="viewsheader text-nowrap">
            <ng-content></ng-content>
            <span *ngIf="isSortedByMeAsc" class="glyphicon glyphicon-triangle-top" aria-hidden="true" ></span>
            <span *ngIf="isSortedByMeDesc" class="glyphicon glyphicon-triangle-bottom" aria-hidden="true"></span>
        </button>`
})
export class PaginationSorter {
    @Input("by") private sortBy: string;
    @Input('pagination') pagination: PaginationComponent;
    @Input("childcolumn") private child: string;
    @Output() notifySorting: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();
    private isSortedByMeAsc: boolean = false;
    private isSortedByMeDesc: boolean = false;
    private isSortChangeEventAdded: boolean = false;
    private gridSortOrderbydiv: Object;
    private gridSortOrderby: string = "none";
    private columnvalue: string = "";
    public constructor() {

    }

    private sort(event: Event) {
        this.pagination.sort_By(this.sortBy, !this.isSortedByMeAsc, this.child);
        this.notifySorting.emit(this.pagination.paginationData);
        //this.columnvalue = $(event.target).text();
        //this.gridSortOrderbydiv = $(event.target).closest("table").siblings(".liveForScreenReaders");
    }

    ngAfterViewChecked() {
        if (this.pagination && !this.isSortChangeEventAdded) {
            this.pagination.onSortChange.subscribe((event: SortEvent) => {
                this.isSortedByMeAsc = (event.sortBy === this.sortBy && event.sortOrder === true);
                this.isSortedByMeDesc = (event.sortBy === this.sortBy && event.sortOrder === false);
                this.gridSortOrderby = this.isSortedByMeAsc ? "ascending" : (this.isSortedByMeDesc ? "descending" : "none");
               // if ($(this.gridSortOrderbydiv).length > 0) {
                 //   $(this.gridSortOrderbydiv).text(this.gridSortOrderby == 'none' ? '' : this.columnvalue + " Sorted " + this.gridSortOrderby);
                //}
            });
            this.isSortChangeEventAdded = true;
        }
    }
}
