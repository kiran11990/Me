﻿export interface IPageChangedEvent {

    itemsPerPage: number;

    page: number;

}