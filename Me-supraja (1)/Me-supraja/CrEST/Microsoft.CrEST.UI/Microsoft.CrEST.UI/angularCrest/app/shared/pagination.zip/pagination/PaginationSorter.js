var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Input, Output, EventEmitter } from "@angular/core";
import { PaginationComponent } from "./pagination.component";
var PaginationSorter = (function () {
    function PaginationSorter() {
        this.notifySorting = new EventEmitter();
        this.isSortedByMeAsc = false;
        this.isSortedByMeDesc = false;
        this.isSortChangeEventAdded = false;
        this.gridSortOrderby = "none";
        this.columnvalue = "";
    }
    PaginationSorter.prototype.sort = function (event) {
        this.pagination.sort_By(this.sortBy, !this.isSortedByMeAsc, this.child);
        this.notifySorting.emit(this.pagination.paginationData);
        //this.columnvalue = $(event.target).text();
        //this.gridSortOrderbydiv = $(event.target).closest("table").siblings(".liveForScreenReaders");
    };
    PaginationSorter.prototype.ngAfterViewChecked = function () {
        var _this = this;
        if (this.pagination && !this.isSortChangeEventAdded) {
            this.pagination.onSortChange.subscribe(function (event) {
                _this.isSortedByMeAsc = (event.sortBy === _this.sortBy && event.sortOrder === true);
                _this.isSortedByMeDesc = (event.sortBy === _this.sortBy && event.sortOrder === false);
                _this.gridSortOrderby = _this.isSortedByMeAsc ? "ascending" : (_this.isSortedByMeDesc ? "descending" : "none");
                // if ($(this.gridSortOrderbydiv).length > 0) {
                //   $(this.gridSortOrderbydiv).text(this.gridSortOrderby == 'none' ? '' : this.columnvalue + " Sorted " + this.gridSortOrderby);
                //}
            });
            this.isSortChangeEventAdded = true;
        }
    };
    return PaginationSorter;
}());
__decorate([
    Input("by"),
    __metadata("design:type", String)
], PaginationSorter.prototype, "sortBy", void 0);
__decorate([
    Input('pagination'),
    __metadata("design:type", PaginationComponent)
], PaginationSorter.prototype, "pagination", void 0);
__decorate([
    Input("childcolumn"),
    __metadata("design:type", String)
], PaginationSorter.prototype, "child", void 0);
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], PaginationSorter.prototype, "notifySorting", void 0);
PaginationSorter = __decorate([
    Component({
        selector: "PaginationSorter",
        template: "\n<style>\n.viewsheader:hover{\ntext-decoration:underline;\n}\n</style>\n        <button [attr.aria-sort]=\"gridSortOrderby\"  role=\"columnheader\" aria-live=\"polite\"  style=\"cursor: pointer;background:none;border:0px;margin-left:-7px\" (click)=\"sort($event)\" class=\"viewsheader text-nowrap\">\n            <ng-content></ng-content>\n            <span *ngIf=\"isSortedByMeAsc\" class=\"glyphicon glyphicon-triangle-top\" aria-hidden=\"true\" ></span>\n            <span *ngIf=\"isSortedByMeDesc\" class=\"glyphicon glyphicon-triangle-bottom\" aria-hidden=\"true\"></span>\n        </button>"
    }),
    __metadata("design:paramtypes", [])
], PaginationSorter);
export { PaginationSorter };
//# sourceMappingURL=PaginationSorter.js.map