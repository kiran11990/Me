var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Component, NgModule, Input, Output, ElementRef, EventEmitter, Self, Renderer } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgModel } from '@angular/forms';
var paginationConfig = {
    setPageMaxSize: void 0,
    itemsPerPage: 10,
    boundaryLinks: true,
    directionLinks: true,
    firstText: 'First',
    previousText: 'Previous',
    nextText: 'Next',
    lastText: 'Last',
    rotate: false
};
var PaginationComponent = (function () {
    function PaginationComponent(cd, renderer, elementRef) {
        this.cd = cd;
        this.renderer = renderer;
        this.elementRef = elementRef;
        this.inited = false;
        this.filterCriteria = {};
        this.gridSortOrder = false;
        this.gridSortColumn = "";
        this.onSortChange = new EventEmitter();
        this.numPages = new EventEmitter();
        this.pageChanged = new EventEmitter();
        this.pageLimitChanged = new EventEmitter(); //TODO: Can we change this to onItemsPerPagechanged
        this.clearFilter = new EventEmitter();
        this.showClearFilter = false;
        this.onChange = function (_) {
        };
        this.onTouched = function () {
        };
        cd.valueAccessor = this;
        this.config = this.config || paginationConfig;
        this.maxItemsperPage = parseInt("5"); //(this._config.getCustom("PaginationItemsPerPage")); 
    }
    Object.defineProperty(PaginationComponent.prototype, "itemsPerPage", {
        get: function () {
            return this._itemsPerPage;
        },
        set: function (v) {
            this._itemsPerPage = v;
            this.recordLimit = v;
            this.totalPages = this.calculateTotalPages();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PaginationComponent.prototype, "totalItems", {
        get: function () {
            return this._totalItems;
        },
        set: function (v) {
            this._totalItems = v;
            this.totalPages = this.calculateTotalPages();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PaginationComponent.prototype, "totalPages", {
        get: function () {
            return this._totalPages;
        },
        set: function (v) {
            this._totalPages = v;
            this.numPages.emit(v);
            if (this.inited) {
                this.selectPage(this.page);
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PaginationComponent.prototype, "page", {
        get: function () {
            return this._page;
        },
        set: function (value) {
            var _previous = this._page;
            this._page = (value > this.totalPages) ? this.totalPages : (value || 1);
            this.pageNumber = this._page;
            if (_previous === this._page || typeof _previous === 'undefined') {
                return;
            }
            this.paging(this._page);
            this.pageChanged.emit({
                page: this._page,
                itemsPerPage: this.itemsPerPage
            });
        },
        enumerable: true,
        configurable: true
    });
    PaginationComponent.prototype.ngOnInit = function () {
        //debugger;       
        this.classMap = this.elementRef.nativeElement.getAttribute('class') || '';
        // watch for setPageMaxSize
        this.setPageMaxSize = typeof this.setPageMaxSize !== 'undefined' ? this.setPageMaxSize : paginationConfig.setPageMaxSize;
        this.rotate = typeof this.rotate !== 'undefined' ? this.rotate : paginationConfig.rotate;
        this.boundaryLinks = typeof this.boundaryLinks !== 'undefined' ? this.boundaryLinks : paginationConfig.boundaryLinks;
        this.directionLinks = typeof this.directionLinks !== 'undefined' ? this.directionLinks : paginationConfig.directionLinks;
        // base class
        this.itemsPerPage = typeof this.itemsPerPage !== 'undefined' ? this.itemsPerPage : paginationConfig.itemsPerPage;
        this.totalPages = this.calculateTotalPages();
        // this class
        this.pages = this.getPages(this.page, this.totalPages);
        this.page = this.cd.value;
        this.inited = true;
    };
    PaginationComponent.prototype.bindDataToPagination = function (data) {
        this.completeData = data;
        this.filterData();
        this.setPageMaxSize = 5;
        this.totalItems = this.originalData.length;
        this.paging(this.page);
        this.pageNumber = this.page;
        this.recordLimit = this.itemsPerPage;
    };
    PaginationComponent.prototype.writeValue = function (value) {
        this.page = value;
        this.pages = this.getPages(this.page, this.totalPages);
    };
    PaginationComponent.prototype.selectPage = function (page, event) {
        if (event) {
            event.preventDefault();
        }
        if (!this.disabled) {
            if (event && event.target) {
                var target = event.target;
                target.blur();
            }
            this.writeValue(page);
            this.cd.viewToModelUpdate(this.page);
        }
    };
    PaginationComponent.prototype.EnterEventPagination = function (page, event) {
        if (event.keyCode == 13) {
            if (event) {
                event.preventDefault();
            }
            if (!this.disabled) {
                if (event && event.target) {
                    var target = event.target;
                    target.blur();
                }
                this.writeValue(page);
                this.cd.viewToModelUpdate(this.page);
            }
        }
    };
    PaginationComponent.prototype.setLimitPagination = function (limit, event) {
        if (event.keyCode == 13) {
            this.setLimit(limit);
        }
    };
    PaginationComponent.prototype.getText = function (key) {
        return this[key + 'Text'] || paginationConfig[key + 'Text'];
    };
    PaginationComponent.prototype.noPrevious = function () {
        return this.page === 1;
    };
    PaginationComponent.prototype.noFilterApplied = function () {
        return !this.isEmpty(this.filterCriteria) && this.showClearFilter;
    };
    PaginationComponent.prototype.isEmpty = function (map) {
        var empty = true;
        for (var key in map) {
            empty = false;
            break;
        }
        return empty;
    };
    PaginationComponent.prototype.noNext = function () {
        return this.page === this.totalPages;
    };
    PaginationComponent.prototype.makePage = function (number, text, isActive) {
        return {
            number: number,
            text: text,
            active: isActive
        };
    };
    PaginationComponent.prototype.getPages = function (currentPage, totalPages) {
        var pages = [];
        // Default page limits
        var startPage = 1;
        var endPage = totalPages;
        //debugger;
        var isMaxSized = typeof this.setPageMaxSize !== 'undefined' && this.setPageMaxSize < totalPages;
        // recompute if maxSize
        if (isMaxSized) {
            if (this.rotate) {
                // Current page is displayed in the middle of the visible ones
                startPage = Math.max(currentPage - Math.floor(this.setPageMaxSize / 2), 1);
                endPage = startPage + this.setPageMaxSize - 1;
                // Adjust if limit is exceeded
                if (endPage > totalPages) {
                    endPage = totalPages;
                    startPage = endPage - this.setPageMaxSize + 1;
                }
            }
            else {
                // Visible pages are paginated with setPageMaxSize
                startPage = ((Math.ceil(currentPage / this.setPageMaxSize) - 1) * this.setPageMaxSize) + 1;
                // Adjust last page if limit is exceeded
                endPage = Math.min(startPage + this.setPageMaxSize - 1, totalPages);
            }
        }
        // Add page number links
        for (var number = startPage; number <= endPage; number++) {
            var page = this.makePage(number, number.toString(), number.toString() === currentPage.toString());
            pages.push(page);
        }
        // Add links to move between page sets
        if (isMaxSized && !this.rotate) {
            if (startPage > 1) {
                var previousPageSet = this.makePage(startPage - 1, '...', false);
                pages.unshift(previousPageSet);
            }
            if (endPage < totalPages) {
                var nextPageSet = this.makePage(endPage + 1, '...', false);
                pages.push(nextPageSet);
            }
        }
        return pages;
    };
    PaginationComponent.prototype.calculateTotalPages = function () {
        var totalPages = this.itemsPerPage < 1 ? 1 : Math.ceil(this.totalItems / this.itemsPerPage);
        return Math.max(totalPages || 0, 1);
    };
    PaginationComponent.prototype.registerOnChange = function (fn) {
        this.onChange = fn;
    };
    PaginationComponent.prototype.registerOnTouched = function (fn) {
        this.onTouched = fn;
    };
    PaginationComponent.prototype.setLimit = function (limit) {
        //debugger;
        this.pageNumber = this.page;
        if (limit < 1 || limit > this.maxItemsperPage)
            this.recordLimit = this._itemsPerPage;
        else
            this.recordLimit = limit;
        this.pageLimitChanged.emit(this.recordLimit);
    };
    PaginationComponent.prototype.isNumber = function (value, evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    };
    PaginationComponent.prototype.restrictZeroONGoToPage = function (value, evt) {
        var reg = /^[0-9]+$/.test(value);
        if (reg == false)
            this.pageNumber = 1;
        value = parseInt(value);
        if (value < 1)
            this.pageNumber = 1;
        //if ((value.trim() === "" || value === "0" || value === "00" || value === "000" || value === "0000") && (evt.char == "0" || evt.char == "\b" || evt.char == "")) {
        //    this.pageNumber = 1;
        //}
    };
    PaginationComponent.prototype.restrictZeroONSetLimit = function (value, evt) {
        //debugger;
        var reg = /^[0-9]+$/.test(value);
        if (reg == false)
            this.recordLimit = this._itemsPerPage;
        value = parseInt(value);
        if (value < 1 || value > this.maxItemsperPage)
            this.recordLimit = this._itemsPerPage;
        //if ((value.trim() === "" || value === "0" || value === "00" || value === "000" || value === "0000") && (evt.char == "0" || evt.char=="\b" || evt.char=="")) {
        //    this.recordLimit = 1;
        //}
    };
    PaginationComponent.prototype.paging = function (page) {
        if (this.originalData) {
            var limit = this.itemsPerPage;
            if (this.totalItems < this.itemsPerPage)
                limit = this.totalItems;
            var row = (page - 1) * limit, count = page * limit, part = [];
            for (; row < count; row++) {
                if (this.originalData[row])
                    part.push(this.originalData[row]);
                else
                    break;
            }
            this.paginationData = part;
        }
    };
    PaginationComponent.prototype.filter_By = function (filterBy, searchStr) {
        this.filterCriteria[filterBy] = { SearchStr: searchStr, Condition: "contains" };
        this.filterData();
    };
    PaginationComponent.prototype.filterHandsOn = function (filterBy, event) {
        this.filterCriteria[filterBy] = event;
        this.filterData();
    };
    PaginationComponent.prototype.filterData = function () {
        var _current = this;
        this.originalData = this.completeData.filter(function (item) {
            var match = true;
            for (var keyName in _current.filterCriteria) {
                var condition = _current.filterCriteria[keyName].Condition;
                var searchStr = _current.filterCriteria[keyName].SearchStr;
                if (condition == "empty" && item[keyName])
                    match = false;
                if (condition == "not_empty" && !item[keyName])
                    match = false;
                if (condition != "not_empty" && condition != "empty" && !item[keyName])
                    match = false;
                if (condition == "eq" && item[keyName] && searchStr &&
                    item[keyName].toString().toLowerCase() != searchStr.toLowerCase())
                    match = false;
                if (condition == "neq" && item[keyName] && searchStr &&
                    item[keyName].toString().toLowerCase() == searchStr.toLowerCase())
                    match = false;
                if (condition == "begins_with" && item[keyName] && searchStr &&
                    !item[keyName].toString().toLowerCase().startsWith(searchStr.toLowerCase()))
                    match = false;
                if (condition == "ends_with" && item[keyName] && searchStr &&
                    !item[keyName].toString().toLowerCase().endsWith(searchStr.toLowerCase()))
                    match = false;
                if (condition == "contains" && item[keyName] && searchStr &&
                    item[keyName].toString().toLowerCase().indexOf(searchStr.toLowerCase()) < 0)
                    match = false;
                if (condition == "not_contains" && item[keyName] && searchStr &&
                    item[keyName].toString().toLowerCase().indexOf(searchStr.toLowerCase()) >= 0)
                    match = false;
            }
            return match;
        });
        this.totalItems = this.originalData.length;
        this.paging(this.page);
        this.page = 1;
    };
    PaginationComponent.prototype.clearFilters = function () {
        if (event) {
            event.preventDefault();
        }
        this.filterCriteria = {};
        this.filterData();
        this.clearFilter.emit(null);
    };
    PaginationComponent.prototype.sort_By = function (sortBy, orderBy, child) {
        if (!orderBy) {
            orderBy = !this.gridSortOrder;
            this.gridSortOrder = !this.gridSortOrder;
        }
        if (this.originalData != undefined) {
            var sortOrder = 1;
            this.originalData.sort(function (a, b) {
                var valueA = a[sortBy];
                var valueB = b[sortBy];
                if (child) {
                    var valueAChild = valueA[child];
                    var valueBChild = valueB[child];
                    if (valueAChild) {
                        valueA = valueAChild;
                    }
                    if (valueBChild) {
                        valueB = valueBChild;
                    }
                }
                if (valueA != null) {
                    if (Number.isInteger(valueA))
                        valueA = parseInt(valueA);
                    else if (Date.parse(valueA))
                        valueA = new Date(valueA);
                    else if (valueA)
                        valueA = valueA.toString().toLowerCase();
                    else
                        valueA = "";
                }
                if (valueB != null) {
                    if (Number.isInteger(valueB))
                        valueB = parseInt(valueB);
                    else if (Date.parse(valueB))
                        valueB = new Date(valueB);
                    else if (valueB)
                        valueB = valueB.toString().toLowerCase();
                    else
                        valueB = "";
                }
                var result;
                if (!valueA)
                    valueA = "";
                if (!valueB)
                    valueB = "";
                if (orderBy)
                    result = (valueA < valueB) ? -1 : (valueA > valueB) ? 1 : 0;
                else
                    result = (valueA > valueB) ? -1 : (valueA < valueB) ? 1 : 0;
                return result * sortOrder;
            });
            this.paging(this.page);
        }
        else {
            this.paging(this.page);
        }
        this.onSortChange.emit({ sortBy: sortBy, sortOrder: orderBy });
    };
    ;
    return PaginationComponent;
}());
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], PaginationComponent.prototype, "numPages", void 0);
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], PaginationComponent.prototype, "pageChanged", void 0);
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], PaginationComponent.prototype, "pageLimitChanged", void 0);
__decorate([
    Output(),
    __metadata("design:type", EventEmitter)
], PaginationComponent.prototype, "clearFilter", void 0);
__decorate([
    Input(),
    __metadata("design:type", Boolean)
], PaginationComponent.prototype, "showClearFilter", void 0);
PaginationComponent = __decorate([
    NgModule({
        imports: [CommonModule]
    }),
    Component({
        selector: 'pagination[ngModel]',
    }),
    __param(0, Self()),
    __metadata("design:paramtypes", [NgModel, Renderer, ElementRef])
], PaginationComponent);
export { PaginationComponent };
//# sourceMappingURL=pagination.component.js.map