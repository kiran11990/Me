﻿import { Component, Input, Output, EventEmitter, OnInit } from "@angular/core";
import { PaginationComponent } from "./pagination.component";

@Component({
    selector: "PaginationFilter",
    template: `
        <input type="text"  [attr.aria-label]="title" [(ngModel)]="filterStr" class="paginationFilter" style="color:black;font-weight:normal;width:80%;height:20px;" class="text-nowrap" id="filterCol{{filterBy}}"/>
        <button (click)="filter()" [attr.aria-label]="title" title="Filter by {{title}}" style="border:none;background:transparent;padding:2px;" ><span style="cursor: pointer;font-family:'Segoe UI Symbol';" id="filterIcon{{filterBy}}">&#xE16E;</span></button>`
})
export class PaginationFilter {
    @Input("by") private filterBy: string;
    @Input('pagination') pagination: PaginationComponent;
    @Output() notifyFilter: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();   
    private filterStr: string = "";
    @Input("title") private title: string = "";
    public constructor() {

    }

    private filter() {
        this.pagination.filter_By(this.filterBy, this.filterStr);
        this.notifyFilter.emit(this.pagination.paginationData);
    }    
}
