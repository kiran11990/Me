﻿import {IAttribute} from './IAttribute';

export interface IPaginationConfig extends IAttribute {

    setPageMaxSize: number;

    itemsPerPage: number;

    boundaryLinks: boolean;

    directionLinks: boolean;

    firstText: string;

    previousText: string;

    nextText: string;

    lastText: string;


    rotate: boolean;

}