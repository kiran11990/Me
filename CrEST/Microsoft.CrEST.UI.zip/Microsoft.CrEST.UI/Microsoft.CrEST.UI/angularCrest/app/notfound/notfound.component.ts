﻿import { Component } from '@angular/core';

@Component({
    selector: 'not-found',
    templateUrl: './notfound.component.html',
})

export class NotFoundComponent {
    pageNotFound: String = "No Items Found..";
}