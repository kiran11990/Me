﻿import { Component } from '@angular/core';
import { ConfigService } from './shared/shared'

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html'
})

export class AppComponent {
}
