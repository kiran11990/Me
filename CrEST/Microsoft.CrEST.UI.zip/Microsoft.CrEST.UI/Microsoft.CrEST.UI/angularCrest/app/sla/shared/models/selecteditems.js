var SelectedItems = (function () {
    function SelectedItems() {
    }
    return SelectedItems;
}());
export { SelectedItems };
//# sourceMappingURL=selecteditems.js.map