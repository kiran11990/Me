var Application = (function () {
    function Application() {
    }
    return Application;
}());
export { Application };
//# sourceMappingURL=application.js.map