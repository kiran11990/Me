﻿export class DropdownList {
    id: Number;
    itemName: String;

}