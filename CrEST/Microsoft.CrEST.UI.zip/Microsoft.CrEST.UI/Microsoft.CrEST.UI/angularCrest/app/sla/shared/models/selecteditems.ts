﻿export class SelectedItems {
    id: Number;
    itemName: String;

}