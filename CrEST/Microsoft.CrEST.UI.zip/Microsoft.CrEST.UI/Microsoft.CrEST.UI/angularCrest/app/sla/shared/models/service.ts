﻿export class Service {
    supplier: string;
    SCID: string;
    contractid: string;
    ApplicationGroup: string;
    CrESTlevel1Servic: string;
    CrESTlevel2Service: string;
    CrESTlevel3Service: string;
    AppGroupServicesFeeYr1: string;
    AppGroupServicesFeeYr2: string;
    AppGroupServicesFeeYr3: string;
    AppGroupServicesFeeYr4: string;
    ValidationNotes: string;
    Remarks: string;
    ITORG: string;
}