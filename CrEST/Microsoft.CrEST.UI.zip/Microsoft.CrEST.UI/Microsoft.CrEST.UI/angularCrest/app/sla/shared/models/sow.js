var Sow = (function () {
    function Sow() {
    }
    return Sow;
}());
export { Sow };
//# sourceMappingURL=sow.js.map