export class Sow {
    supplier: string;
    serviceLine: string;
    contractID: string;
    sowEffectiveDate: string;
}

