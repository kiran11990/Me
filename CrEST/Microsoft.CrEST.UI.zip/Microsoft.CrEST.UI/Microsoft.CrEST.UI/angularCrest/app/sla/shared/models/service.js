var Service = (function () {
    function Service() {
    }
    return Service;
}());
export { Service };
//# sourceMappingURL=service.js.map