﻿export class Application {
    application: string
    contactId: string
    serviceLine: string
    serviceClass: string
    runVsGrow: string
    applicatioGroup: string 
    startDate: string
    endDate: string
    serviceLineChk: string
    endToEnd: string
    epm: string
    tm: string
    managedCapacity: string
    managedServices: string
    applicationChk:string
    softwareAssetSearchableID: string
    remarks: string

}