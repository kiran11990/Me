﻿import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'sla-slp',
    templateUrl: './slp.component.html',
})

export class SlpComponent {
    sla_slp: "Sla Service Level Performance";
}