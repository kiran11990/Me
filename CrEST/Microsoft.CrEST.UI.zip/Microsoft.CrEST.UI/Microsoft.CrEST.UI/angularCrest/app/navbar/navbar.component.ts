﻿import { Component } from '@angular/core';

@Component({
    selector: 'crest-nav-bar',
    templateUrl: './navbar.component.html',
})

export class NavigationComponent {}